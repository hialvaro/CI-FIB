// A proposal for your code... Just to inspire you
#include <xc.h>
#define _XTAL_FREQ 8000000
#include "config.h"
#define LED PORTAbits.RA0
#define LED1 PORTAbits.RA1
#define LED2 PORTAbits.RA2
#define LED3 PORTAbits.RA3
#define LED4 PORTAbits.RA4
#define PUJA PORTBbits.RB1
#define BAIXA PORTBbits.RB0
#define APAGA 0
#define ENCEN 1
void configPIC(){
//config PIC
ANSELA=0x00; // All pins as digital
ANSELB=0x00; // All pins as digital
TRISA=0x00;
TRISB=0xFF;
PORTA = 0x00;
}

void main(void){
configPIC();
int niv = 0;
int antp = 0;
int antb = 0;
while(1) {
   
 /***************PREVI****************/
   /*if(BAIXA == 1){ //esta pulsado
      LED = ENCEN;
      } else{
	    LED = 0;
	 } PROGRAMA 1*/
   
   /*if(BAIXA == 1)ant = 1;    
   else{
      if(ant == 1){
	 LED = !LED;
	 ant =0;
	 }      
      } PROGRAMA 2*/
/*****************************************/
   
   if(PUJA == 0)antp = 0;    
   else{
      if(antp == 0){
	 if(niv < 5){
	    ++niv;
	    __delay_ms(20);
	      if(niv == 1){
	       LED = ENCEN;
	     }
	     else if(niv == 2){
		LED1 = ENCEN;
		}
	    else if(niv == 3){
		LED2 = ENCEN;
		}
	    else if(niv == 4){
		LED3 = ENCEN;
		}
	    else if(niv == 5){
	       LED4 = ENCEN;
		}
	    }		
	 antp =1; 
      }
   }
   
   if(BAIXA == 0)antb = 0;    
   else{
      if(antb == 0){
	 if(niv >= 0){
	    __delay_ms(20);
	      if(niv == 1){
	       LED = APAGA;
	     }
	     else if(niv == 2){
		LED1 = APAGA;
		}
	    else if(niv == 3){
		LED2 = APAGA;
		}
	    else if(niv == 4){
		LED3 = APAGA;
		}
	    else if(niv == 5){
	       LED4 = APAGA;
		}
	    }		
	 antb =1;
	 if(niv > 0) --niv; 
      }
   }
   

   
   
     
}//END WHILE(1)
}//END MAIN
