#include <xc.h>
#include "config.h"
#define _XTAL_FREQ 8000000
#define A0 PORTAbits.RA0
#define A1 PORTAbits.RA1
#define A2 PORTAbits.RA2
#define A3 PORTAbits.RA3
#define B0 PORTBbits.RB0
#define B1 PORTBbits.RB1
#define B2 PORTBbits.RB2
#define B3 PORTBbits.RB3

void configPIC(){
 //config PIC
 ANSELA=0; // All pins as digital
 ANSELD=0; // All pins as digital
 TRISA = 0x30;
 TRISB = 0xFF; //b AS INPUT
 PORTB = 0;
 TRISD=0;
 PORTA = 0;
   
}
int selec = 0;
int b1 = 0;
int b2 = 0;
int b3 = 0;
int antc = 0;
int antp = 0;
int antb = 0;
int antd = 0;
void printit(int digit){
   switch(digit){
	 case 1: 
	    PORTD = 0x06;
	    __delay_ms(5);
	    break;
	 case 2: 
	    PORTD = 0x5B;
	    __delay_ms(5);
	    break;
	 case 3: 
	    PORTD = 0x4F;
	    __delay_ms(5);
	    break;
	 case 4: 
	      PORTD = 0x66;
	      __delay_ms(5);
	       break;
	 case 5: 
	    PORTD = 0x6D;
	    __delay_ms(5);
	       break;
	 case 6: PORTD = 0x7D;
	    __delay_ms(5);
	       break;
	 case 7: PORTD = 0x07;
	    __delay_ms(5);
	       break;
	 case 8: PORTD = 0x7F;
	    __delay_ms(5);
	       break;
	 case 9: PORTD = 0x67;
	    __delay_ms(5);
	       break;
	 default: 
	    PORTD = 0x3F;
	    __delay_ms(5);
	    break;
	 }
   }
void printdigit(int digit, int pos){ 
   if(pos == 0){
      PORTA = 0x01;
      printit(digit);
      }
   if(pos == 1){
	 PORTA = 0x02;
	 printit(digit);
      }
   if(pos == 2){
	 PORTA = 0x04;
	 printit(digit);
	 } 
   if(pos > 2){
	    PORTA = 0x08;
	    printit(digit);
	    }
	 }

void printnum(int a){
   int digit;
   int pos = 0;
   while(a>=10){
      digit = a%10;
      printdigit(digit, pos);
      a = a/10;
      ++pos;
   }
      printdigit(a, pos);
      __delay_ms(5);
}

void printnumU (int a){
   int digit;
   int pos = 0;
   while(a>=10){
      digit = a%10;
      printdigit(digit, pos);
      a = a/10;
      ++pos;
   }
      printdigit(a, pos);
      printdigit(0, 1);
      printdigit(0,2);
      __delay_ms(5);
}

void printnumD (int a){
   int digit;
   int pos = 0;
   while(a>=10){
      digit = a%10;
      printdigit(digit, pos);
      a = a/10;
      ++pos;
   }
      printdigit(a, pos);
      printdigit(0,2);
      __delay_ms(5);
}
   
void sobre(void){   
if(B0 == 0)antc = 0;    
   else{
      if(antc == 0){
      __delay_ms(10);
      ++selec;
      selec = selec%3;
      }
      antc = 1;
   }
   
if(B1 == 0)antp = 0;    
   else{
      if(antp == 0){
      __delay_ms(10);
      switch(selec){
	 case 0:
	    ++b1;
	    break;
	 case 1:
	    ++b2;
	    break;
	 case 2:
	    ++b3;
	    break;
	 default:
	    break;
	 }
    }
    antp = 1;
 }
    

    
if(B2 == 0)antb = 0;    
   else{
      if(antb == 0){
       __delay_ms(10);
      switch(selec){
	 case 0:
	    if(b1>0)--b1;
	    break;
	 case 1:
	    if(b2>0)--b2;
	    break;
	 case 2:
	    if(b3>0)--b3;
	    break;
	 default:
	    break;
	 }
	 antb = 1;
    }
 }
    
  b1 = b1%10;
  b2 = b2%10;
  b3 = b3%10;
  int digit = b3*100 + b2*10 + b1;
    
if(B3 == 0)antd = 0;    
   else{
       if(antd == 0){
     while(digit > 0){
	printnum(digit--);	
     }
     b1 = b2 = b3 = 0;
     antd = 1;
  }
  }
  
  if(digit < 10) printnumU(digit);
  else if(digit < 100) printnumD(digit);
  else printnum(digit);   
 }

void incr(void)
 {
	int vec[10] = {0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x67};
	A0=1;
	A1=1;
	A2=1;
	A3=1;
	int x=0;
	while(1){
		PORTD = vec[x];
		x= x+1;
		__delay_ms(250);
	}
 }

void main(void){
 configPIC();

 while(1) {
    sobre();
 }
}