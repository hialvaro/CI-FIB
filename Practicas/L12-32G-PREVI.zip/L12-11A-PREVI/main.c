#include <xc.h>
#define _XTAL_FREQ 8000000  
#define PINB1 PORTBbits.RD1
#define PINB2 PORTBbits.RD2

#define GIEH INTCONbits.GIEH
#define GIEL INTCONbits.GIEL
#define RAIE INTCONbits.RAIE

#define INTEDG0 INTCON2bits.INTEDG0
#define INTEDG1 INTCON2bits.INTEDG1 
#define INTEDG2 INTCON2bits.INTEDG2 

#define INT1IP INTCON3bits.INT1IP 
#define INT2IP INTCON3bits.INT2IP 
#define INT0IE INTCONbits.INT0IE 
#define INT1IE INTCON3bits.INT1IE 
#define INT2IE INTCON3bits.INT2IE 
#define INT0IF INTCONbits.INT0IF 
#define INT1IF INTCON3bits.INT1IF 
#define INT2IF INTCON3bits.INT2IF 
#define TMR0ON T0CONbits.TMR0ON 
#define T08BIT T0CONbits.T08BIT 
#define T0CS T0CONbits.T0CS 
#define T0SE T0CONbits.T0SE 
#define T0PSA T0CONbits.PSA 
#define T0PS2 T0CONbits.T0PS2 
#define T0PS1 T0CONbits.T0PS1 
#define T0PS0 T0CONbits.T0PS0 
//interrupciones
#define GIEH INTCONbits.GIEH
#define TMR0IE INTCONbits.TMR0IE 
#define TMR0IF INTCONbits.TMR0IF 

#define  IPEN RCONbits.IPEN

#include <string.h>
#include "config.h"
#include "GLCD.h"

byte pi,pj;
const char  *s3 = "$\n";
const char  *s1 = " \n";
//const char *s4 = "No es una poscion valida \n"

void writeTxt(byte page, byte y, char * s) {
	int i=0;
	while (*s!='\n') { 
		putch(page, y+i, *(s++));
		i++;
	};
}	
void interrupt high_ISR(void){
   
   if(PIR1bits.CCP1IF && PIE1bits.CCP1IE){
	 PIR1bits.CCP1IF = 0;
	 TMR1 = 0;
      }
   }

void configpic(){
   //1
   TRISA = 0xFF;
   ANSELA = 0xFF;
   ANSELD = 0x00;
   TRISD = 0x00;
   ANSELB = 0x00;
   TRISB = 0x00;
   ANSELC = 0x00;
   //2
   ADCON2bits.ADCS = 0b001;//configurar clock
   
   ADCON2bits.ADFM = 0b1;//RIGHT JUSTIFY --> RESULTAT CONVERSI� A 'ADRESH<1:0>:ADRESL<7:0>'
   ADCON2bits.ACQT = 0b100;//M'ASEGURO MAX ACQUISITION TIME
   
   VREFCON0bits.FVRST = 0b0; //FLAG NO VREF NO ESTABLE 
   VREFCON0bits.FVRS = 0b10; //rango [-2,2]v
   VREFCON0bits.FVREN = 0b1; //enable
   
   ADCON0bits.CHS = 0b00000;//AN0 INPUT
   ADCON2bits.ADFM = 0b1; //Justificado a la derecha
   ADCON2bits.ACQT = 0b100; //4*Tad
   
   ADCON0bits.ADON = 0b1;//ACTIVA CONVERSI�
   
 
   
   
   GLCDinit();		   //Inicialitzem la pantalla
   clearGLCD(0,7,0,127);      //Borrem pantalla
   setStartLine(0);           //Definim inici
   pj = 0;
   
   }

   void configuraINT(){
      TRISCbits.TRISC2 = 0;
      CCP1CON = 0b00000010;
      IPR1bits.CCP1IP = 1;
      PIR1bits.CCP1IF = 0;
      PIE1bits.CCP1IE = 1;
      T1CON = 0x81;
      TMR1H = 0;
      TMR1L = 0;
      CCPR1 = 4492;
      }
void escribirPant(int a, double b){
   writeTxt(0,5,"Valor AD\n");
   writeNum(1,5,a);
   writeTxt(2,5,"nota HZ\n");
   writeNum(3,5,b);
   writeTxt(4,5,"Periode en us\n");
   long int us = (1/b)*1000000;
   writeNum(5,5,us);
   
}
      
void main(void)
 {
    configpic();
    configuraINT();
    int i,f;
    while(1){
	  ADCON0bits.GO = 1;
	  while(ADCON0bits.GO == 1);
	  if(i != ADRES) {
	     clearGLCD(0,7,0,127);   
	  i = ADRES;
	  f = i*3+300;
	  long int nccp = (long int)2000000/((long int)f*(long int)2);
	  CCPR1 = nccp;
	     }
	  escribirPant(i,f);
	for(int k = 0; k < 10000; k++);
	 
      }
	
	 
}
