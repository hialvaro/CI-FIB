#include <xc.h>
#include "config.h"
#define _XTAL_FREQ 8000000
#define IPEN RCONbits.IPEN // Definim IPEN
int d1 = 0;
 
void configPIC(){
 //config PIC
 ANSELB=0; // All pins as digital
 ANSELD=0; // All pins as digital
 TRISB = 1;
 TRISA = 0;
 PORTA = 1;
 TRISD=0;
 IPEN = 1; //Activem l'esquema de prioritats.
 INTCONbits.INT0IE = 1; //Enable interrupcions INTCON (INT0 alta prior).
 INTCONbits.GIEL = 1; //Enable interrupcions baixa prior.
 INTCONbits.GIEH = 1; //Enable interrupcions alta prior.
 INTCONbits.INT0IE = 1; //Enable INT0.
 INTCON3bits.INT2IP = 0; //INT2 com a low priority.
 INTCON3bits.INT1IP = 0; //INT1 com a low priority.
 INTCON3bits.INT2IE = 1; //Enable INT2.
 INTCON3bits.INT1IE = 1; //Enable INT1.
 INTCON2bits.INTEDG0 = 0;
 INTCON2bits.INTEDG1 = 1;
 INTCON2bits.INTEDG2 = 1;
}

void printit(int digit){
   switch(digit){
	 case 1: 
	    PORTD = 0x06;
	    __delay_ms(5);
	    break;
	 case 2: 
	    PORTD = 0x5B;
	    __delay_ms(5);
	    break;
	 case 3: 
	    PORTD = 0x4F;
	    __delay_ms(5);
	    break;
	 case 4: 
	      PORTD = 0x66;
	      __delay_ms(5);
	       break;
	 case 5: 
	    PORTD = 0x6D;
	    __delay_ms(5);
	       break;
	 case 6: PORTD = 0x7D;
	    __delay_ms(5);
	       break;
	 case 7: PORTD = 0x07;
	    __delay_ms(5);
	       break;
	 case 8: PORTD = 0x7F;
	    __delay_ms(5);
	       break;
	 case 9: PORTD = 0x67;
	    __delay_ms(5);
	       break;
	 default: 
	    PORTD = 0x3F;
	    __delay_ms(5);
	    break;
	 }
   }
void printdigit(int digit, int pos){
   if(pos == 0){
      PORTA = 0x01;
      printit(digit);
      }
   if(pos == 1){
	 PORTA = 0x02;
	 printit(digit);
      }
   if(pos == 2){
	 PORTA = 0x04;
	 printit(digit);
	 } 
   if(pos > 2){
	    PORTA = 0x08;
	    printit(digit);
	    }
	 }

void printnum(int a){
   int digit;
   int pos = 0;
   while(a>=10){
      digit = a%10;
      printdigit(digit, pos);
      a = a/10;
      ++pos;
   }
      printdigit(a, pos);
   }
   
void interrupt highRSI(void){
   if(INTCONbits.INT0IF && INTCONbits.INT0IE){
      d1 = 0;
      INTCONbits.INT0IF = 0;
      }
   }
   
void interrupt low_priority lowRSI(void){
   if(INTCON3bits.INT1IF && INTCON3bits.INT1IE){
      //Si es la interrupci� de INT1, llavors hem de augmentar.
      __delay_ms(5);
      ++d1;
      d1 %= 1000;
      INTCON3bits.INT1IF = 0;
    }
    
    else if(INTCON3bits.INT2IF && INTCON3bits.INT2IE){
      //Si es la interrupci� de INT2, llavors hem de disminuir.
       __delay_ms(5);
      --d1;
       d1%= 1000;
       INTCON3bits.INT2IF = 0;
    }
   }


void main(void){
 configPIC();

 while(1) {
    printnum(d1);
}
}